rocks_trees = {
   { name = [[system]], root = [[/home/cabox/workspace/xd/.luarocks]] }
}
