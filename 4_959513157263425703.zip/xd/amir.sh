clear
figlet amir  
 echo -e "\033[38;5;208m"
echo -e "  ThisIsAmiR Best BOT Developer    "
echo -e "  MY Channel  Team : @OffLiNeTeam "
echo -e "  Me In Telegram : @This_Is_AmiR Messnger Bot : @This_Is_AmiRBot  "
echo -e "  Messnger Bot : @This_Is_AmiRBot  "
echo -e "                                              \033[0;00m"
echo -e "\e[36m"