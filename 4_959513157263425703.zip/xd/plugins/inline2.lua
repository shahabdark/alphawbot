local api_key = '219298173:AAH9-Mb_v2GQBjwKdLS5nZBAhTiIk-RBnlQ'
local function run(msg,matches)
    local text = '`ФŦŦŁłЛΞTΞΛm SuppФЯ੮`'
    local channel_id = get_receiver_api(msg)
    local link_text = 'Click Me For Join'
    local data = load_data(_config.moderation.data)
    local link = data[tostring(1051588599)]['settings']['set_link']
    local keyboard = '{"inline_keyboard":[[{"text":"'..link_text..'","url":"'..link..'"}]]}'
    local url = 'https://api.telegram.org/bot'..api_key..'/sendMessage?chat_id='..channel_id..'&parse_mode=Markdown&text='..text..'&disable_web_page_preview=true&reply_markup='..keyboard
    local dat, res = https.request(url)
      if res == 400 then
         reply_msg(msg.id, 'Error !', ok_cb, true)    
         else
         return   
      end
      end
  return {
      patterns = {
          "^[!/#]linksup$"
          },
      run = run
  }