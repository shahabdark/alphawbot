do

function run(msg, matches)
  return [[B L A C K +
-----------------------------------
A new bot for manage your SuperGroups.
-----------------------------------
@Black_CH #Channel
-----------------------------------
@MehdiHS #developer
-----------------------------------
@YflQw #manager
-----------------------------------
@Mr_Surena #manager
-----------------------------------
Bot number : +19092545429
-----------------------------------
Bot version : 6.7 ]]
end
return {
  description = ".", 
  usage = "use black command",
  patterns = {
    "^/black$",
    "^!black$",
    "^%bLack$",
    "^$black$",
   "^#Black$",
   "^#Black",
   "^/black$",
   "^#black$",

  },
  run = run
}
end
