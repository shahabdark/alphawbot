function run(msg, matches)
 local url = http.request("http://api.magic-team.ir/musicsearch.php?q="..URL.escape(matches[2]).."&count=30&sort=2")
local jdat = json:decode(url)
 local text , time , num = ''
 local hash = 'music:'..msg.to.peer_id
 redis:del(hash)
 if #jdat.response < 2 then return "No result found." end
  for i = 2, #jdat.response do
   if 900 > jdat.response[i].duration then
   num = i - 1
   time = sectomin(jdat.response[i].duration)
   text = text..num..'- Artist: '.. jdat.response[i].artist .. ' | '..time..'\nTitle: '..jdat.response[i].title..'\n\n'
   redis:hset(hash, num, 'Artist: '.. jdat.response[i].artist .. '\nTitle: '..jdat.response[i].title..' | '..time..'\n\n'.."[Download](http://GPMod.ir/dl.php?q="..jdat.response[i].owner_id.."_"..jdat.response[i].aid..')')
   end
  end
  text = text..'\n----------------------\n*Use the following command to download*.\n\n`!dl <number>`\n\n*(example)*: `!dl 1`\n\n[LionTeam](telegram.me/lionteam)'
return text
end
return {
 patterns = {
 "^[#!/]([Mm][Uu][Ss][Ii][Cc]) (.*)$",
 "^[#!/]([dD][Ll]) (.*)$"
 }, 
 run = run 
}
