do function run(msg, matches)
if matches[1]:lower() == 'id' and is_momod(msg) then
local text = "> `Group ID`: *"..msg.to.id.."*\n\n> `Group Name`: *"..msg.to.title.."*\n\n> `First Name`: *"..(msg.from.first_name or '').."*\n\n> `Last Name`: *"..(msg.from.last_name or '').."*\n\n> `Your ID`: *"..msg.from.id.."*\n\n> `Username`: @"..(msg.from.username or '').."\n\n> `Number`: +"..(msg.from.phone or '')
send_api_msg(msg, get_receiver_api(msg), text, true, 'md')
end
end
return {
description = "show your id",
usage = "Id : show your userid",
patterns = {
"^[!/#]([Ii][Dd])$",
"^[Ii][Dd]$",
},
run = run
}
end
