local function run(msg,matches)
if matches[1] == 'bot' and matches[2] == 'token' then
          _config.bot_api = {key = '', uid = '', uname = ''}
        end
        _config.bot_api.key = matches[3]
        _config.bot_api.uid = matches[3]:match('^%d+')
        save_config()
        local text = '<code>New Token Seted</code>'
  send_api_msg(msg, get_receiver_api(msg), text, true, 'html')
 end
return {
 patterns = {'^[#!/](set) (.*) (%g+)$'},
 run = run }