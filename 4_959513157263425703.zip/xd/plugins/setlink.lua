 local function run(msg, matches)
    if matches[1] == 'setlink' and is_owner(msg) then
      data[tostring(msg.to.id)]['settings']['set_link'] = 'waiting'
      save_data(_config.moderation.data, data)
      return 'Please send the new group link now'
    end

    if msg.text then
      if msg.text:match("^(https://telegram.me/joinchat/%S+)$") and data[tostring(msg.to.id)]['settings']['set_link'] == 'waiting' and is_owner(msg) then
        data[tostring(msg.to.id)]['settings']['set_link'] = msg.text
        save_data(_config.moderation.data, data)
        return "New link set"
      end
    end
return {
  patterns = {
 "^[!#/](setlink)$"
  },
  run = run,
}
end