local function run(msg)
local text = [[*OFFLINETG Ver :* 2.1
`An Administrator The PowerFull Bot Based On TeleSeed And Created With` [OFFLINETEAM](telegram.me/offlineteam)

_Sudo Users_ :

`Developer&Founder` : [AMIR](telegram.me/this_is_amir)
`Developer&Manager` : [AliReZa](telegram.me/Mr_Clown_Developer)

*Team Channel :*
[Join Us :D](telegram.me/offlineteam)

_Special Thx To :_
`ShahabDark`
`SEEDTEAM`
`And All My Friends :D`]]
    send_api_msg(msg, get_receiver_api(msg), text, true, 'md')
end
return {
 patterns = {"^[!/#]OffLiNeTG$","[/!#]offlinetg"},
 run = run }
