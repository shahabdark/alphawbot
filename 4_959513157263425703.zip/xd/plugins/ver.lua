local function run(msg)
local text = [[*OFFLINETG Ver :* 2.1
  
*Plz Send*
  
`[!/#]OFFLINETG`
  
_For More Information_ 
Dev [ThisIsAmir](http://telegram.me/this_is_amir)
Ch [OffLiNeTeam](http://telegram.me/spheroch)
TNX to all
`And All My Friends :D`]]
    send_api_msg(msg, get_receiver_api(msg), text, true, 'md')
end
return {
 patterns = {"^[!#/][Vv]er","^[!#/][Vv]erion"},
 run = run }
