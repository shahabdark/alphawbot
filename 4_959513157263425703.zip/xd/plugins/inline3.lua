local api_key = '226250543:AAGoTgPgJeVX8QUSB-1ZylporojjW0jBiIU'
local function run(msg,matches)
    local text = 'hi'
    local channel_id = -124691063
    local link_text = 'channel'
    local link = 'https://telegram.me/joinchat/CtSvvgduonfYyQ72L3fN8A'
    local keyboard = '{"inline_keyboard":[[{"text":"'..link_text..'","url":"'..link..'"}]]}'
    local url = 'https://api.telegram.org/bot'..api_key..'/sendMessage?chat_id='..channel_id..'&parse_mode=Markdown&text='..text..'&disable_web_page_preview=true&reply_markup='..keyboard
    local dat, res = https.request(url)
      if res == 400 then
         reply_msg(msg.id, 'Error !', ok_cb, true)    
         else
         reply_msg(msg.id, 'Sent ! See!', ok_cb, true)    
      end
      end
  return {
      patterns = {
          "^[!/#]linkss$"
          },
      run = run
  }