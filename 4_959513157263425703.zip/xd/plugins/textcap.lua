local function run(msg, matches)
local text = '[ ⁩]('..matches[2]..')'..matches[1]
local chat = get_receiver_api(msg)
send_api_msg2(msg, chat, text, true, 'md')
end
return {
  patterns = {
  "^!textcap (.*) (.*)$",
  },
  run = run
}