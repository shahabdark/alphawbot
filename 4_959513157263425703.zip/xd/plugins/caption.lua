local function run(msg,matches)
local photo2 = './data/stickers/amir.jpg'
local caption_text = test
send_photo2(chat_id, photo2, caption_text, ok_cb, false)
  end
return {
  patterns = {
 "^[#!/](caption)$",
  },
  run = run,
}