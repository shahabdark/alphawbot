do

function run(msg, matches)
    local data = load_data(_config.moderation.data)
      local group_link = data[tostring(124691063)]['settings']['set_link']
       if not group_link then
      return ''
       end
  local text = "`Group Link`\n\n [Support Link]("..group_link..")" 
   send_api_msg(msg, get_receiver_api(msg), text, true, 'md')
end
return {
  patterns = {
    "^ ",
    "^[/#!]([Ll]inksup)$",
 "^([Ll]inksup)$"
  },
  run = run
}

end