function run(msg, matches)
if not is_sudo(msg) then
return 
end
text = io.popen("curl http://thisisamir.xzn.ir/time/time.php "):read('*all')
  return text
end
return {
  patterns = {
    '^[#/!][Tt]ime$'
  },
  run = run,
  moderated = true
}