do

function run(msg, matches)
  return [[
  :|
  ]]

  end
return {
  description = ":|", 
  usage = ":|",
  patterns = {
    "^😐$",
    "^/😐$",
    "^!😐$",
    "^😐$",
    "^:|$"
  },
  run = run
}
end