do

function run(msg, matches)
  return [[
#Sudoers!
  
  1.@MehdiHS🌐 #Developer ( use #adddeveloper command to add #Mehdi_HS in your Groups & SuperGroups. )
  
  2.@YflQw🌐 #Manager ( use #addmanager command to add #Vandad_Yflqw in your Groups & SuperGroups. )
  
]]
end
return {
  description = " ", 
  usage = " ",
  patterns = {
    "^[#!/]sudoers$",

  },
  run = run
}
end
